<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Donasi extends CI_Controller {


	public function __construct()
	 {
	   parent::__construct();
	   $this->load->helper(array('form','url','file'));
	 }
	
	public function index() {
	if($this->session->userdata('login')==FALSE):
	redirect('muzakki');
	else:
	$data=array('pagetitle'=>'Pondok Yatim H.Caong',
				'menu' => $this->db->get('menu')->result(),
				'muzakki' => $this->db->get_where('muzakki', array('userName' =>$this->session->userdata('userName')))->row(),
 				'view' =>'contains/donasi'	
 				);
	$this->load->view('template/wrapper',$data);
	endif;
 	}

 	public function jenisdonasi($idJenisDonasi=0) {
 	if($this->session->userdata('login')==FALSE):
	redirect('muzakki');
	else:
	$data=array('pagetitle'=>'Pondok Yatim H.Caong',
				'muzakki' => $this->db->get_where('muzakki', array('userName' =>$this->session->userdata('userName')))->row(),
 				'view' =>'contains/formdonasi'	
 				);
	$this->db->select('*');
	$this->db->from('rekening');
	$this->db->join('jenis_donasi', 'jenis_donasi.idJenisDonasi = rekening.idJenisDonasi');
	$this->db->where('rekening.idJenisDonasi', $idJenisDonasi);
	$data['rek']=$this->db->get()->result();
	$this->load->view('template/wrapper',$data);
	endif;
 	}

 	
	
	public function donasi_proses(){
		$data = array(
				'idMuzakki' => $this->input->post('idMuzakki'),
				'tglDonasi' => date("d-M-Y"),
				'nominal' => $this->input->post('jmldonasi'),
				'noRekening' => $this->input->post('rek'),
				'statusDonasi' => "1",
				'jenisdonasi' => $this->input->post('jenisdonasi')
				);
	$this->db->insert('donasi',$data);
	redirect('donasi/histori');
	}
	
	public function histori() {
		$muzakki = $this->db->get_where('muzakki', array('userName' => $this->session->userdata('userName')))->row_array();
		$data=array('pagetitle'=>'Pondok Yatim H.Caong',
				'menu' => $this->db->get('menu')->result(),
				'muzakki' => $this->db->get_where('muzakki', array('userName' =>$this->session->userdata('userName')))->row_array(),
 				'view' =>'contains/histori'	
 				);
		$this->db->select('donasi.idDonasi, donasi.tglDonasi, donasi.nominal, jenis_donasi.namaJenisDonasi, statusdonasi.idStatusDonasi, statusdonasi.ketDonasi');
		$this->db->from('donasi');
		$this->db->join('statusdonasi', 'donasi.statusDonasi = statusdonasi.idStatusDonasi');
		$this->db->join('jenis_donasi', 'donasi.jenisdonasi = jenis_donasi.idJenisDonasi');
		$this->db->where('donasi.idMuzakki', $muzakki['idMuzakki']);
		$data['hasildonasi']=$this->db->get()->result();
		$this->load->view('template/wrapper',$data);
	}

	public function konfirmasi($idDonasi=0){
		if($this->input->post(NULL,true)):
		$this->load->library('upload');
     	$config['upload_path'] = './assets/img/transfer/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';;
		$config['max_size']     = '1024';
		$this->upload->initialize($config);
		 if ( ! $this->upload->do_upload('gambar'))
             {
               $error = array('error' => $this->upload->display_errors());
               $this->session->set_flashdata("error", " <div class=\"alert alert-warning\"><strong>ERROR!!!</strong>".$error['error']."</div>");
				$muzakki = $this->db->get_where('muzakki', array('userName' => $this->session->userdata('userName')))->row_array();
				$data=array('pagetitle'=>'Pondok Yatim H.Caong',
						'menu' => $this->db->get('menu')->result(),
						'muzakki' => $this->db->get_where('muzakki', array('userName' =>$this->session->userdata('userName')))->row(),
		 				'view' =>'contains/konfirmasi_donasi'	
		 				);
				$this->db->select('donasi.idDonasi, donasi.tglDonasi, donasi.nominal, jenis_donasi.namaJenisDonasi, statusdonasi.ketDonasi');
				$this->db->from('donasi');
				$this->db->join('muzakki', 'donasi.idMuzakki = muzakki.idMuzakki');
				$this->db->join('jenis_donasi', 'donasi.jenisdonasi = jenis_donasi.idJenisDonasi');
				$this->db->where('donasi.idDonasi', $idDonasi);
				$this->db->where('donasi.idMuzakki', $muzakki['idMuzakki']);
				$data['konfirmasidonasi']=$this->db->get()->row();
				$this->load->view('template/wrapper',$data);
				}
                else
                {
	             $data['insert']=array('idMuzakki'=>$this->input->post('idMuzakki', true),
	             					'idDonasi'=> $this->input->post('idDonasi', true),
	             					'tglKonfirmasi'=>date("d-M-Y"),
									'namaPemilikRek'=>$this->input->post('nama', true),
									'noRekPemilik'=>$this->input->post('no', true),
									'gambar'=>$this->upload->file_name
									);
	             

				$this->db->insert('konfirmasi_donasi',$data['insert']);
				
				$this->data['ubahstatus'] = array ('statusDonasi'=>2);
				$this->db->where('idDonasi', $idDonasi);
				$this->db->update('donasi', $this->data['ubahstatus']);
				
				redirect('home','refresh');
                }
           else:
           	$muzakki = $this->db->get_where('muzakki', array('userName' => $this->session->userdata('userName')))->row_array();
				$data=array('pagetitle'=>'Pondok Yatim H.Caong',
						'menu' => $this->db->get('menu')->result(),
						'muzakki' => $this->db->get_where('muzakki', array('userName' =>$this->session->userdata('userName')))->row(),
		 				'view' =>'contains/konfirmasi_donasi'	
		 				);
				$this->db->select('donasi.idDonasi, donasi.tglDonasi, donasi.nominal, jenis_donasi.namaJenisDonasi, muzakki.namaLengkap');
				$this->db->from('donasi');
				$this->db->join('muzakki', 'donasi.idMuzakki = muzakki.idMuzakki');
				$this->db->join('jenis_donasi', 'donasi.jenisdonasi = jenis_donasi.idJenisDonasi');
				$this->db->where('donasi.idMuzakki', $muzakki['idMuzakki']);
				$this->db->where('donasi.idDonasi', $idDonasi);
				$data['konfirmasidonasi']=$this->db->get()->row();
				$this->load->view('template/wrapper',$data);
		endif;
	}

	
}