<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Register_sukses extends CI_Controller {
	
	public function index() {
 	$data=array('pagetitle'=>'Berita Pondok Yatim H.Caong',
				'menu' => $this->db->get('menu')->result(),
 				'view' =>'contains/register_sukses'	
 				);
	$this->load->view('template/wrapper',$data);
 	}
}