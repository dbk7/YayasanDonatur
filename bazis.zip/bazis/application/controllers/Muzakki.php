<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Muzakki extends CI_Controller {
	
	public function index() {
	if ($this->session->userdata('login') == FALSE)
    {
 	$data=array('pagetitle'=>'Pondok Yatim H.Caong',
				'menu' => $this->db->get('menu')->result(),
 				'view' =>'contains/muzakki_login'	
 				);
	$this->load->view('template/wrapper',$data);
		}else{
			redirect('home');
		}
 	}
	
	public function register(){
	$data=array('pagetitle'=>'Pondok Yatim H.Caong',
				'menu' => $this->db->get('menu')->result(),
 				'view' =>'contains/muzakki_register'	
 				);
	$this->load->view('template/wrapper',$data);
	}
	
	public function register_proses() {
		$password = $this->input->post('password');
	    $data = array(
			'userName' => $this->input->post('username'),
            'namaLengkap' => $this->input->post('namalengkap'),
            'email' => $this->input->post('email'),
			'tglLahir' => $this->input->post('tgllahir'),
			'jenisKelamin' => $this->input->post('jeniskelamin'),
            'noTlp' => $this->input->post('notlp'),
			'alamat' => $this->input->post('alamat'),
            'password' => MD5($password),
			);
       $this->db->insert('muzakki', $data);
   redirect('register_sukses');
   }
   
    public function login_proses() {
		$this->load->model('muzakki_m', 'login', TRUE);
		$data=array('pagetitle'=>'Login Donatur Pondok Yatim H.Caong',
				'menu' => $this->db->get('menu')->result(),
 				'view' =>'contains/muzakki_login'	
 				);
        if ($this->session->userdata('login') == TRUE)
        {
		redirect('home');
		}else{
        if($this->login->check_member())
        {
        redirect('home');
        }else{
		$data=array('pagetitle'=>'Berita Pondok Yatim H.Caong',
				'menu' => $this->db->get('menu')->result(),
 				'view' =>'contains/muzakki_login'	
 				);
       $this->load->view('template/wrapper',$data);
              }
        }
    }

    function logout() {
        $this->session->sess_destroy();
        redirect('home');
    }
   
}