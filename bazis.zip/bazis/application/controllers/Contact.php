<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Contact extends CI_Controller {
	
	public function index() {
 	$data=array('pagetitle'=>'Pondok Yatim H.Caong',
				'contact' => $this->db->get('contact')->result(),
				'menu' => $this->db->get('menu')->result(),
 				'view' =>'contains/contact'	
 				);
	$this->load->view('template/wrapper',$data);
 	}
}