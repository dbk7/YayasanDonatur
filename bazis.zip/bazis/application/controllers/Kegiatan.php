<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Kegiatan extends CI_Controller {
	
	public function index() {
	$this->db->order_by('waktuPost', 'desc');
 	$data=array('pagetitle'=>'Kegiatan Pondok Yatim H.Caong',
 				'kegiatan' => $this->db->get('kegiatan')->result(),
				'menu' => $this->db->get('menu')->result(),
 				'view' =>'contains/kegiatan'	
 				);
	$this->load->view('template/wrapper',$data);
 	}

 	public function read($idKegiatan=0) {
 	$this->db->where('idKegiatan',$idKegiatan);
 	$data=array('pagetitle'=>'Kegiatan Pondok Yatim H.Caong',
 				'kegiatan' => $this->db->get('kegiatan')->row(),
				'menu' => $this->db->get('menu')->result(),
 				'view' =>'contains/readkegiatan'	
 				);
	$this->load->view('template/wrapper',$data);
 	}

}