<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Rekening extends CI_Controller {
	
	public function index() {
	$this->db->select('*');
	$this->db->from('rekening');
	$this->db->join('jenis_donasi', 'jenis_donasi.idJenisDonasi = rekening.idJenisDonasi');
 	$data=array('pagetitle'=>'Pondok Yatim H.Caong',
 				'rekening' => $this->db->get()->result(),
 				'view' =>'contains/rekening'	
 				);
	$this->load->view('template/wrapper',$data);
 	}
}