<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Home extends CI_Controller {
	
	public function index() {
	$this->db->order_by('waktuPost', 'desc');
 	$data=array('pagetitle'=>'Pondok Yatim H.Caong',
				'kegiatan' => $this->db->get('kegiatan')->result(),
				'menu' => $this->db->get('menu')->result(),
				'article' => $this->db->get('article')->result(),
 				'view' =>'contains/home/wrap_home'		
 				);
	$this->load->view('template/wrapper',$data);
 	}
}