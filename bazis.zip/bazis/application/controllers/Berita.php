<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Berita extends CI_Controller {
	
	public function index() {
 	$data=array('pagetitle'=>'Berita Pondok Yatim H.Caong',
 				'berita' => $this->db->get('berita')->result(),
				'menu' => $this->db->get('menu')->result(),
 				'view' =>'contains/berita'	
 				);
	$this->load->view('template/wrapper',$data);
 	}

 	public function read($idBerita=0) {
 	$this->db->where('idBerita',$idBerita);
 	$data=array('pagetitle'=>'Pondok Yatim H.Caong',
 				'berita' => $this->db->get('berita')->row(),
				'menu' => $this->db->get('menu')->result(),
 				'view' =>'contains/readberita'	
 				);
	$this->load->view('template/wrapper',$data);
 	}
}