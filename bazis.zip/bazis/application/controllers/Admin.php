<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct()
	 {
	   parent::__construct();
	   $this->load->helper(array('form','url','file'));
	 }


	public function index()
	{
		
		if($this->session->userdata('logged_in'))
	   	{
	     $session_data = $this->session->userdata('logged_in');
	     $this->data=array('pagetitle'=>'Halaman Administrator',
	     					'view'=> 'admin/contains/dashboard'
 					);
		$this->load->view('admin/template/wrapper',$this->data);
	   	}else{
	     //Jika tidak ada session di kembalikan ke halaman login
	     redirect('admin/login_index', 'refresh');
	 	}
   }

    function login_index()
 	{
   	if($this->session->userdata('logged_in'))
   	{
     redirect('admin', 'refresh');
   	}else {
   		$data=array('pagetitle'=>'Halaman Administrator'
 					);
      $this->load->helper(array('form'));
      $this->load->view('template/head',$data);
      $this->load->view('admin/contains/login_form');
   		}
 	}


 	 function logout()
	 {
   	$this->session->unset_userdata('logged_in');
   	session_destroy();
   	redirect('admin/login_index', 'refresh');
 	}


 	function databerita()
 	{
 		if($this->session->userdata('logged_in'))
   		{
   		$this->data=array('pagetitle'=>'Data Berita',
	     					'view'=> 'admin/contains/berita',
	     					'read'=> $this->db->get('berita')->result()
 					);
		$this->load->view('admin/template/wrapper',$this->data);
		}else{
			redirect('admin');
		}
 	}

 	function tambahberita(){

 	if($this->input->post(NULL,true)):
		$this->load->library('upload');
     	$config['upload_path'] = './assets/img/berita/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';;
		$config['max_size']     = '1280';
		$config['max_width'] = '1280';
		$config['max_height'] = '720';
		$this->upload->initialize($config);

		 if ( ! $this->upload->do_upload('fotoBerita'))
             {
               $error = array('error' => $this->upload->display_errors());
               $this->session->set_flashdata("error", " <div class=\"alert alert-warning\"><strong>ERROR!!!</strong>".$error['error']."</div>");
               $this->data=array('pagetitle'=>'Tambah Data Berita',
							'view'=> 'admin/contains/v_tambahberita'
	 						);
				$this->load->view('admin/template/wrapper',$this->data);
                }
                else
                {
	             $data['insert']=array('judulBerita'=>$this->input->post('judulBerita', true),
									'deskripsi'=>$this->input->post('deskripsi', true),
									'waktuPost'=>date('d F Y'),
									'fotoBerita'=>$this->upload->file_name
									);
				$this->db->insert('berita',$data['insert']);
				redirect('admin/databerita','refresh');
                }
        else:
        $this->data=array('pagetitle'=>'Tambah Data Berita',
							'view'=> 'admin/contains/v_tambahberita'
	 						);
		$this->load->view('admin/template/wrapper',$this->data);
		endif;

 	}

 	function hapusberita($idBerita=0){
	 $this->db->where('idBerita',$idBerita);
     $query = $this->db->get('berita');
     $row = $query->row();
     unlink('./assets/img/berita/'.$row->fotoBerita);
   	 $this->db->delete('berita', array('idBerita' => $idBerita));
   	 redirect('admin/berita');
	}

	function editberita($idBerita=0){
	 
	 if($this->input->post(NULL,true)):
		$this->load->library('upload');
     	$config['upload_path'] = './assets/img/berita/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';;
		$config['max_size']     = '1280';
		$config['max_width'] = '1280';
		$config['max_height'] = '720';
		$this->upload->initialize($config);

		 if (! $this->upload->do_upload('fotoBerita'))
             {

               $data['insert']=array('judulBerita'=>$this->input->post('judulBerita', true),
									'deskripsi'=>$this->input->post('deskripsi', true),
									'waktuPost'=>date('d F Y'),
									'fotoBerita'=>$this->input->post('fotoDefault', true)
									);
	            $this->db->where('idBerita',$idBerita);
				$this->db->update('berita',$data['insert']);
				redirect('admin/databerita','refresh');
                }
                else
                {
	            $data['insert']=array('judulBerita'=>$this->input->post('judulBerita', true),
									'deskripsi'=>$this->input->post('deskripsi', true),
									'waktuPost'=>date('d F Y'),
									'fotoBerita'=>$this->upload->file_name
									);
	            $this->db->where('idBerita',$idBerita);
				$this->db->update('berita',$data['insert']);
				redirect('admin/databerita','refresh');
                }
        else:
        $this->db->where('idBerita', $idBerita);
        $this->data=array('pagetitle'=>'Edit Data Berita',
							'view'=> 'admin/contains/v_editberita',
							'berita'=>$this->db->get('berita')->row()
	 						);
		$this->load->view('admin/template/wrapper',$this->data);
		endif;

	}


 	function kegiatan()
 	{
 		if($this->session->userdata('logged_in'))
   		{
   		$this->data=array('pagetitle'=>'Data Kegiatan',
	     					'view'=> 'admin/contains/kegiatan_v',
	     					'read'=> $this->db->get('kegiatan')->result()
 					);
		$this->load->view('admin/template/wrapper',$this->data);
		}else{
			redirect('admin');
		}
 	}

 	function hapuskegiatan($idKegiatan=0){
	 $this->db->where('idKegiatan',$idKegiatan);
     $query = $this->db->get('kegiatan');
     $row = $query->row();
     unlink('./assets/img/kegiatan/'.$row->fotoKegiatan);
   	 $this->db->delete('kegiatan', array('idKegiatan' => $idKegiatan));
   	 redirect('admin/kegiatan');
	}


	function tambahkegiatan(){

 	if($this->input->post(NULL,true)):
		$this->load->library('upload');
     	$config['upload_path'] = './assets/img/kegiatan/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';;
		$config['max_size']     = '1280';
		$config['max_width'] = '1280';
		$config['max_height'] = '720';
		$this->upload->initialize($config);

		 if ( ! $this->upload->do_upload('fotoKegiatan'))
             {
               $error = array('error' => $this->upload->display_errors());
               $this->session->set_flashdata("error", " <div class=\"alert alert-warning\"><strong>ERROR!!!</strong>".$error['error']."</div>");
               $this->data=array('pagetitle'=>'Tambah Data Kegiatan',
							'view'=> 'admin/contains/v_tambahkegiatan'
	 						);
				$this->load->view('admin/template/wrapper',$this->data);
                }
                else
                {
	             $data['insert']=array('judulKegiatan'=>$this->input->post('judulKegiatan', true),
									'deskripsi'=>$this->input->post('deskripsi', true),
									'waktuPost'=>date('d F Y'),
									'fotoKegiatan'=>$this->upload->file_name
									);
				$this->db->insert('kegiatan',$data['insert']);
				redirect('admin/kegiatan','refresh');
                }
        else:
        $this->data=array('pagetitle'=>'Tambah Data Kegiatan',
							'view'=> 'admin/contains/v_tambahkegiatan'
	 						);
		$this->load->view('admin/template/wrapper',$this->data);
		endif;

 	}


 	function editkegiatan($idKegiatan=0){
	 
	 if($this->input->post(NULL,true)):
		$this->load->library('upload');
     	$config['upload_path'] = './assets/img/kegiatan/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';;
		$config['max_size']     = '1280';
		$config['max_width'] = '1280';
		$config['max_height'] = '720';
		$this->upload->initialize($config);

		 if (! $this->upload->do_upload('fotoKegiatan'))
             {
             	
                $data['insert']=array('judulKegiatan'=>$this->input->post('judulKegiatan', true),
									'deskripsi'=>$this->input->post('deskripsi', true),
									'waktuPost'=>date('d F Y'),
									'fotoKegiatan'=>$this->input->post('fotoDefault', true)
									);
	            $this->db->where('idKegiatan',$idKegiatan);
				$this->db->update('kegiatan',$data['insert']);
				redirect('admin/kegiatan','refresh');
                }
                else
                {
	            $data['insert']=array('judulKegiatan'=>$this->input->post('judulKegiatan', true),
									'deskripsi'=>$this->input->post('deskripsi', true),
									'waktuPost'=>date('d F Y'),
									'fotoKegiatan'=>$this->upload->file_name
									);
	            $this->db->where('idKegiatan',$idKegiatan);
				$this->db->update('kegiatan',$data['insert']);
				redirect('admin/kegiatan','refresh');
                }
        else:
        $this->db->where('idKegiatan', $idKegiatan);
        $this->data=array('pagetitle'=>'Edit Kegiatan',
							'view'=> 'admin/contains/v_editkegiatan',
							'kegiatan'=>$this->db->get('kegiatan')->row()
	 						);
		$this->load->view('admin/template/wrapper',$this->data);
		endif;

	}

	function datarekening(){
		if($this->session->userdata('logged_in')){

		$this->db->select('*');
		$this->db->from('rekening');
		$this->db->join('jenis_donasi', 'jenis_donasi.idJenisDonasi = rekening.idJenisDonasi');
		$this->data=array('pagetitle'=>'Data Rekening',
							'view'=> 'admin/contains/v_datarekening',
							'rekening'=>$this->db->get()->result()
	 						);
		$this->load->view('admin/template/wrapper',$this->data);	

		}else{
			redirect('admin');
		}

	}

	function tambahrekening(){
		if($this->session->userdata('logged_in')){
			if($this->input->post(NULL,true)):
				 $data['insert']=array('namaBank'=>$this->input->post('namaBank', true),
									'noRekening'=>$this->input->post('noRekening', true),
									'idJenisDonasi'=>$this->input->post('idJenisDonasi', true)
									);
				$this->db->insert('rekening',$data['insert']);
				redirect('admin/datarekening','refresh');
			else:
				$this->data=array('pagetitle'=>'Tambah Rekening Baru',
									'view'=> 'admin/contains/v_tambahrekening',
									'jenisdonasi'=>$this->db->get('jenis_donasi')->result()
			 						);
				$this->load->view('admin/template/wrapper',$this->data);
			endif;	

		}else{
			redirect('admin');
		}

	}

	function hapusrekening($idrekening=0){
	if($this->session->userdata('logged_in')){
		 $this->db->where('idrekening',$idrekening);
	   	 $this->db->delete('rekening', array('idrekening' => $idrekening));
	   	 redirect('admin/datarekening');
	   	}else{
	   		redirect('admin');
	   	}
	}


	function editrekening($idrekening=0){
	if($this->session->userdata('logged_in')){
			if($this->input->post(NULL,true)):
				 $data['update']=array('namaBank'=>$this->input->post('namaBank', true),
									'noRekening'=>$this->input->post('noRekening', true),
									'idJenisDonasi'=>$this->input->post('idJenisDonasi', true)
									);
				$this->db->where('idrekening', $idrekening);
				$this->db->update('rekening',$data['update']);
				redirect('admin/datarekening','refresh');
			else:
				$this->db->where('idrekening', $idrekening);
				$this->data=array('pagetitle'=>'Edit Rekening',
									'view'=> 'admin/contains/v_editrekening',
									'rekening' => $this->db->get('rekening')->row(),
									'jenisdonasi'=>$this->db->get('jenis_donasi')->result()
			 						);
				$this->load->view('admin/template/wrapper',$this->data);
			endif;	

		}else{
			redirect('admin');
		}

	}

	function datacontact(){
		if($this->session->userdata('logged_in')){

		$this->db->select('*');
		$this->db->from('contact');
		$this->data=array('pagetitle'=>'Data Contact',
							'view'=> 'admin/contains/v_datacontact',
							'contact'=>$this->db->get()->result()
	 						);
		$this->load->view('admin/template/wrapper',$this->data);	

		}else{
			redirect('admin');
		}
	}

	function tambahcontact(){
		if($this->session->userdata('logged_in')){
			if($this->input->post(NULL,true)):
				 $data['insert']=array('descContact'=>$this->input->post('descContact', true),
									'emailContact'=>$this->input->post('emailContact', true),
									'tlpContact'=>$this->input->post('tlpContact', true),
									'faxContact'=>$this->input->post('faxContact', true)
									);
				$this->db->insert('contact',$data['insert']);
				redirect('admin/datacontact','refresh');
			else:
				$this->data=array('pagetitle'=>'Tambah Contact Baru',
									'view'=> 'admin/contains/v_tambahcontact'
			 						);
				$this->load->view('admin/template/wrapper',$this->data);
			endif;	

		}else{
			redirect('admin');
		}

	}

	function editcontact($idcontact=0){
		if($this->session->userdata('logged_in')){
			if($this->input->post(NULL,true)):
				 $data['update']=array('descContact'=>$this->input->post('descContact', true),
									'emailContact'=>$this->input->post('emailContact', true),
									'tlpContact'=>$this->input->post('tlpContact', true),
									'faxContact'=>$this->input->post('faxContact', true)
									);
				$this->db->where('idContact', $idcontact);
				$this->db->update('contact',$data['update']);
				redirect('admin/datacontact','refresh');
			else:
				$this->db->where('idContact', $idcontact);
				$this->data=array('pagetitle'=>'Edit Contact',
									'view'=> 'admin/contains/v_editcontact',
									'contact' => $this->db->get('contact')->row()
			 						);
				$this->load->view('admin/template/wrapper',$this->data);
			endif;	

		}else{
			redirect('admin');
		}
	}

	function hapuscontact($idcontact=0){
		if($this->session->userdata('logged_in')){
		 $this->db->where('idContact',$idcontact);
	   	 $this->db->delete('contact', array('idContact' => $idcontact));
	   	 redirect('admin/datacontact');
	   	}else{
	   		redirect('admin');
	   	}
	}

	function datastatusdonasi(){
		if($this->session->userdata('logged_in')){

		$this->db->select('*');
		$this->db->from('statusdonasi');
		$this->data=array('pagetitle'=>'Data Status Donasi',
							'view'=> 'admin/contains/v_datastatusdonasi',
							'statusdonasi'=>$this->db->get()->result()
	 						);
		$this->load->view('admin/template/wrapper',$this->data);	

		}else{
			redirect('admin');
		}
	}

	function tambahstatusdonasi(){
		if($this->session->userdata('logged_in')){
			if($this->input->post(NULL,true)):
				 $data['insert']=array('ketDonasi'=>$this->input->post('ketDonasi', true)
									);
				$this->db->insert('statusdonasi',$data['insert']);
				redirect('admin/datastatusdonasi','refresh');
			else:
				$this->data=array('pagetitle'=>'Tambah Status Donasi Baru',
									'view'=> 'admin/contains/v_tambahstatusdonasi'
			 						);
				$this->load->view('admin/template/wrapper',$this->data);
			endif;	

		}else{
			redirect('admin');
		}
	}

	function editstatusdonasi($idstatusdonasi=0){
		if($this->session->userdata('logged_in')){
			if($this->input->post(NULL,true)):
				 $data['update']=array('ketDonasi'=>$this->input->post('ketDonasi', true)
									);
				$this->db->where('idStatusDonasi', $idstatusdonasi);
				$this->db->update('statusdonasi',$data['update']);
				redirect('admin/datastatusdonasi','refresh');
			else:
				$this->db->where('idStatusDonasi', $idstatusdonasi);
				$this->data=array('pagetitle'=>'Edit Status Donasi',
									'view'=> 'admin/contains/v_editstatusdonasi',
									'statusdonasi' => $this->db->get('statusdonasi')->row()
			 						);
				$this->load->view('admin/template/wrapper',$this->data);
			endif;	

		}else{
			redirect('admin');
		}
	}

	function hapusstatusdonasi($idstatusdonasi=0){
		if($this->session->userdata('logged_in')){
		 $this->db->where('idStatusDonasi',$idstatusdonasi);
	   	 $this->db->delete('statusdonasi', array('idStatusDonasi' => $idstatusdonasi));
	   	 redirect('admin/datastatusdonasi');
	   	}else{
	   		redirect('admin');
	   	}
	}

	function datamuzakki(){
		if($this->session->userdata('logged_in')){

		$this->db->select('*');
		$this->db->from('muzakki');
		$this->data=array('pagetitle'=>'Data Muzakki',
							'view'=> 'admin/contains/v_datamuzakki',
							'muzakki'=>$this->db->get()->result()
	 						);
		$this->load->view('admin/template/wrapper',$this->data);	

		}else{
			redirect('admin');
		}
	}

	function donasibelumkonfirm(){
		if($this->session->userdata('logged_in')){
			
				$this->db->select('*');
				$this->db->from('donasi');
				$this->db->join('muzakki', 'muzakki.idMuzakki = donasi.idMuzakki', 'left');
				$this->db->join('jenis_donasi', 'jenis_donasi.idJenisDonasi = donasi.jenisdonasi', 'left');
				$this->db->join('statusdonasi', 'statusdonasi.idStatusDonasi = donasi.statusDonasi', 'left');
				$this->db->join('konfirmasi_donasi', 'konfirmasi_donasi.idDonasi = donasi.idDonasi', 'left');
				$this->db->where('statusdonasi.idStatusDonasi', '1');
				$this->data=array('pagetitle'=>'Donasi Belum Konfirmasi',
									'view'=> 'admin/contains/v_donasibelumkonfirm',
									'donasi'=>$this->db->get()->result()
			 						);
				$this->db->select('SUM(nominal) as total');
				$this->db->from('donasi');
				$this->db->join('muzakki', 'muzakki.idMuzakki = donasi.idMuzakki', 'left');
				$this->db->join('jenis_donasi', 'jenis_donasi.idJenisDonasi = donasi.jenisdonasi', 'left');
				$this->db->join('statusdonasi', 'statusdonasi.idStatusDonasi = donasi.statusDonasi', 'left');
				$this->db->join('konfirmasi_donasi', 'konfirmasi_donasi.idDonasi = donasi.idDonasi', 'left');
				$this->db->where('statusdonasi.idStatusDonasi', '1');
				$this->data['total']=$this->db->get()->row()->total;
				$this->load->view('admin/template/wrapper',$this->data);
			
		}else{
			redirect('admin');
		}
	}

	function ubahstatusdonasi($idDonasi=0){
		$data['update']=array('statusDonasi'=>'2');
		$this->db->where('idDonasi', $idDonasi);
		$this->db->update('donasi',$data['update']);
		$this->session->set_flashdata("pesan", "<div class=\"col-md-12\"><div class=\"alert alert-success text-center\" id=\"alert\">Data donasi sudah dikonfirmasi!</div></div>");
		redirect('admin/donasibelumkonfirm', 'refresh');
	}
 	

 	function donasimasuk(){
		if($this->session->userdata('logged_in')){
			
				$this->db->select('*');
				$this->db->from('donasi');
				$this->db->join('muzakki', 'muzakki.idMuzakki = donasi.idMuzakki', 'left');
				$this->db->join('jenis_donasi', 'jenis_donasi.idJenisDonasi = donasi.jenisdonasi', 'left');
				$this->db->join('statusdonasi', 'statusdonasi.idStatusDonasi = donasi.statusDonasi', 'left');
				$this->db->join('konfirmasi_donasi', 'konfirmasi_donasi.idDonasi = donasi.idDonasi', 'left');
				$this->db->where('statusdonasi.idStatusDonasi', '2');
				$this->data=array('pagetitle'=>'Donasi Belum Konfirmasi',
									'view'=> 'admin/contains/v_donasimasuk',
									'donasi'=>$this->db->get()->result()
			 						);
				$this->db->select('SUM(nominal) as total');
				$this->db->from('donasi');
				$this->db->join('muzakki', 'muzakki.idMuzakki = donasi.idMuzakki', 'left');
				$this->db->join('jenis_donasi', 'jenis_donasi.idJenisDonasi = donasi.jenisdonasi', 'left');
				$this->db->join('statusdonasi', 'statusdonasi.idStatusDonasi = donasi.statusDonasi', 'left');
				$this->db->join('konfirmasi_donasi', 'konfirmasi_donasi.idDonasi = donasi.idDonasi', 'left');
				$this->db->where('statusdonasi.idStatusDonasi', '2');
				$this->data['total']=$this->db->get()->row()->total;
				$this->load->view('admin/template/wrapper',$this->data);
			
		}else{
			redirect('admin');
		}
	}


	function penyaluran(){
		if($this->session->userdata('logged_in')){

			if($this->input->post(NULL,true)):
				 $data['insert']=array('tglPenyaluran'=>date("d-M-Y"),
				 						'nominalPenyaluran'=>$this->input->post('nominalPenyaluran', true),
				 						'tujuan'=>$this->input->post('tujuan', true),
				 						'keterangan'=>$this->input->post('keterangan', true)
									);
				$this->db->insert('penyaluran',$data['insert']);
				redirect('admin/penyaluran','refresh');
			else:
				$this->data=array('pagetitle'=>'Penyaluran Dana',
									'view'=> 'admin/contains/v_penyaluran',
									'penyaluran' => $this->db->get('penyaluran')->result()
			 						);
				$this->db->select('SUM(nominal) as total');
				$this->db->from('donasi');
				$this->db->join('muzakki', 'muzakki.idMuzakki = donasi.idMuzakki', 'left');
				$this->db->join('jenis_donasi', 'jenis_donasi.idJenisDonasi = donasi.jenisdonasi', 'left');
				$this->db->join('statusdonasi', 'statusdonasi.idStatusDonasi = donasi.statusDonasi', 'left');
				$this->db->where('statusdonasi.idStatusDonasi', '2');
				$this->data['total']=$this->db->get()->row()->total;
				$this->db->select('SUM(nominalPenyaluran) as total');
				$this->db->from('penyaluran');
				$this->data['totalout']=$this->db->get()->row()->total;
				$this->load->view('admin/template/wrapper',$this->data);
			endif;	

		}else{
			redirect('admin');
		}

	}


	function laporan(){
		if($this->session->userdata('logged_in')){

			$this->db->select('*');
				$this->db->from('donasi');
				$this->db->join('muzakki', 'muzakki.idMuzakki = donasi.idMuzakki', 'left');
				$this->db->join('jenis_donasi', 'jenis_donasi.idJenisDonasi = donasi.jenisdonasi', 'left');
				$this->db->join('statusdonasi', 'statusdonasi.idStatusDonasi = donasi.statusDonasi', 'left');
				$this->db->where('statusdonasi.idStatusDonasi', '2');  
				
				$this->data=array('pagetitle'=>'Laporan Keuangan',
									'view'=> 'admin/contains/v_laporan',
									'donasi'=>$this->db->get()->result(),
									'penyaluran' => $this->db->get('penyaluran')->result()
			 						);
				$this->db->select('SUM(nominal) as total');
				$this->db->from('donasi');
				$this->data['total']=$this->db->get()->row()->total;

				$this->db->select('SUM(nominalPenyaluran) as total');
				$this->db->from('penyaluran');
				$this->data['totalout']=$this->db->get()->row()->total;
				
				$this->load->view('admin/template/wrapper',$this->data);

		}else{
			redirect('admin');
		}

	}

function laporan2(){
		
		if($this->session->userdata('logged_in')){

			$this->db->select('*');
				$this->db->from('donasi');
				$this->db->join('muzakki', 'muzakki.idMuzakki = donasi.idMuzakki', 'left');
				$this->db->join('jenis_donasi', 'jenis_donasi.idJenisDonasi = donasi.jenisdonasi', 'left');
				$this->db->join('statusdonasi', 'statusdonasi.idStatusDonasi = donasi.statusDonasi', 'left');
				$this->db->where('statusdonasi.idStatusDonasi', '2');  
				$this->db->where('(MONTH(tglDonasi)','$_GET['bulan']');
				$this->data=array('pagetitle'=>'Laporan Keuangan',
									'view'=> 'admin/contains/v_laporan2',
									'donasi'=>$this->db->get()->result(),
									'penyaluran' => $this->db->get('penyaluran')->result()
			 						);
				$this->db->select('SUM(nominal) as total');
				$this->db->from('donasi');
				$this->data['total']=$this->db->get()->row()->total;

				$this->db->select('SUM(nominalPenyaluran) as total');
				$this->db->from('penyaluran');
				$this->data['totalout']=$this->db->get()->row()->total;
				
				$this->load->view('admin/template/wrapper',$this->data);

		}else{
			redirect('admin');
		}

	}

	function chart(){

		$this->db->select('*');
		$this->db->like('tglDonasi','2016-');
		$this->db->order_by('tglDonasi','asc');
		$chart=$this->db->get('testdonasi');
		foreach ($chart->result() as $row)
		$data[] = (int) $row->nominal;
		$this->load->view('welcome_message',array('data'=>$data));

	}


}
