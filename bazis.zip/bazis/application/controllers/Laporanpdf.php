<?php
Class Laporanpdf extends CI_Controller{
    
    function __construct() {
        parent::__construct();
          
      $this->load->library('pdf');
    }
    
    function index(){
        $pdf = new FPDF('l','mm','A5');
        // membuat halaman baru
        $pdf->AddPage();
        // setting jenis font yang akan digunakan
        $pdf->SetFont('Arial','B',16);
        // mencetak string 
        $pdf->Cell(190,7,'SEKOLAH MENENGAH KEJURUSAN NEEGRI 2 LANGSA',0,1,'C');
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,7,'DAFTAR SISWA KELAS IX JURUSAN REKAYASA PERANGKAT LUNAK',0,1,'C');
        // Memberikan space kebawah agar tidak terlalu rapat
        $pdf->Cell(10,7,'',0,1);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(20,6,'ID',1,0);
        $pdf->Cell(65,6,'NOMINAL',1,0);
        $pdf->Cell(37,6,'NO REKENING',1,0);
        $pdf->Cell(35,6,'TANGGAL DONASI',1,1);
        $pdf->SetFont('Arial','',10);
        $mahasiswa = $this->db->get('donasi')->result();
        foreach ($mahasiswa as $row){
            $pdf->Cell(20,6,$row->idMuzakki,1,0);
            $pdf->Cell(65,6,$row->nominal,1,0);
            $pdf->Cell(37,6,$row->noRekening,1,0);
            $pdf->Cell(35,6,$row->tglDonasi,1,1); 
        }
        $pdf->Output();
    }
}