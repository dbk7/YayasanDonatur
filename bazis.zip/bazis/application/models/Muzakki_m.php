<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Muzakki_m extends CI_Model {

     public function check_member()
    {
        $userName = $this->input->post('userName');
        $password = md5($this->input->post('password'));

        $query = $this->db->where('userName', $userName)
                          ->where('password', $password)
                          ->limit(1)
                          ->get('muzakki');

        if ($query->num_rows() == 1)
        {
            $data = array('userName' => $userName, 'idMuzakki' => $idMuzakki, 'login' => TRUE);
            $this->session->set_userdata($data);
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }

    public function logout()
    {
        $this->session->unset_userdata(array('userName' => $userName, 'password' => $password, 'login' => FALSE));
        $this->session->sess_destroy();
	}

    public function check_admin()
    {
        $userName = $this->input->post('userName');
        $password = md5($this->input->post('password'));

        $query = $this->db->where('userName', $userName)
                          ->where('password', $password)
                          ->limit(1)
                          ->get('admin');

        if ($query->num_rows() == 1)
        {
            $data = array('userName' => $userName, 'userId' => $userId, 'login_adm' => TRUE);
            $this->session->set_userdata($data);
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
}