<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Halaman Admin Bazis Jakbar</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $this->session->userdata('fullname')?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                       
                        <li>
                            <a href="<?=base_url('admin/logout')?>"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="
                    <?php if($this->uri->segment(1) == 'admin' && $this->uri->segment(2) == '' ){
                            echo 'active';
                            }
                    ?>"
                    >
                        <a href="<?=base_url('admin')?>"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#menu"><i class="fa fa-fw fa-edit"></i> Master Data <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="menu" class="
                        <?php if($this->uri->segment(2) == TRUE){
                            echo 'collapse in';
                            }else{
                            echo 'collapse';
                            }
                        ?>"
                        >
                            <li style="
                            <?php if($this->uri->segment(2) == 'databerita'){
                            echo 'background-color: black;';
                            }else{
                            echo '';
                            }
                            ?>
                            ">
                            <a href="<?=base_url('admin/databerita')?>"><i class="fa fa-fw fa-bar-chart-o"></i> Berita</a>
                            </li>
                            <li style="
                            <?php if($this->uri->segment(2) == 'kegiatan'){
                            echo 'background-color: black;';
                            }else{
                            echo '';
                            }
                            ?>
                            ">
                                <a href="<?=base_url('admin/kegiatan')?>"><i class="fa fa-fw fa-table"></i> Kegiatan</a>
                            </li>
                         
                            <li style="
                            <?php if($this->uri->segment(2) == 'datarekening'){
                            echo 'background-color: black;';
                            }else{
                            echo '';
                            }
                            ?>
                            ">
                                <a href="<?=base_url('admin/datarekening')?>"><i class="fa fa-fw fa-desktop"></i> Rekening</a>
                            </li>
                            <li style="
                            <?php if($this->uri->segment(2) == 'datacontact'){
                            echo 'background-color: black;';
                            }else{
                            echo '';
                            }
                            ?>
                            ">
                                <a href="<?=base_url('admin/datacontact')?>"><i class="fa fa-fw fa-table"></i> Contact</a>
                            </li>
                             <li style="
                            <?php if($this->uri->segment(2) == 'datastatusdonasi'){
                            echo 'background-color: black;';
                            }else{
                            echo '';
                            }
                            ?>
                            ">
                                
                                <a href="<?=base_url('admin/datastatusdonasi')?>"><i class="fa fa-fw fa-check-square-o"></i> Status Donasi</a>
                            </li>
                        </ul>
                    </li>

                    <li style="
                            <?php if($this->uri->segment(2) == 'datamuzakki'){
                            echo 'background-color: black;';
                            }else{
                            echo '';
                            }
                            ?>
                            ">
                        <a href="<?=base_url('admin/datamuzakki')?>"><i class="fa fa-fw fa-users"></i> Data Muzakki</a>
                    </li>
                    
                    <li style="
                            <?php if($this->uri->segment(2) == 'donasibelumkonfirm'){
                            echo 'background-color: black;';
                            }else{
                            echo '';
                            }
                            ?>
                            ">
                        <a href="<?=base_url('admin/donasibelumkonfirm')?>"><i class="fa fa-fw fa-table"></i> Donasi Belum Konfirmasi</a>
                    </li>
                    <li style="
                            <?php if($this->uri->segment(2) == 'donasimasuk'){
                            echo 'background-color: black;';
                            }else{
                            echo '';
                            }
                            ?>
                            ">
                        <a href="<?=base_url('admin/donasimasuk')?>"><i class="fa fa-fw fa-table"></i> Donasi Diterima</a>
                    </li>
                    <li style="
                            <?php if($this->uri->segment(2) == 'penyaluran'){
                            echo 'background-color: black;';
                            }else{
                            echo '';
                            }
                            ?>
                            ">
                        <a href="<?=base_url('admin/penyaluran')?>"><i class="fa fa-fw fa-table"></i> Penyaluran ZIS</a>
                    </li>
                      <li style="
                            <?php if($this->uri->segment(2) == 'laporan'){
                            echo 'background-color: black;';
                            }else{
                            echo '';
                            }
                            ?>
                            ">
                        <a href="<?=base_url('admin/laporan')?>"><i class="fa fa-fw fa-table"></i> Laporan Keuangan</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>