   <!-- jQuery -->
    <script src="<?=base_url()?>assets/adm_assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?=base_url()?>assets/adm_assets/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>assets/adm_assets/js/plugins/tinymce/tinymce.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="<?=base_url()?>assets/adm_assets/js/plugins/morris/raphael.min.js"></script>
    <script src="<?=base_url()?>assets/adm_assets/js/plugins/morris/morris.min.js"></script>
    <script src="<?=base_url()?>assets/adm_assets/js/plugins/morris/morris-data.js"></script>

    <script  type="text/javascript">
            tinymce.init({
            selector: "textarea"
            });
	</script>

</body>

</html>