<?php
require_once('head.php');
require_once('header_nav.php');
require_once('konten.php');
require_once('footer.php');
