<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Tambah Contact Baru
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Tambah Contact Baru
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                
                <div class="row">
                    <div class="col-lg-6">
                     <form action="<?= site_url('admin/tambahcontact');?>" method="post" accept-charset="utf-8" id="formberita">
                            <div class="form-group" style="margin-bottom: 5px;">
                                <label style="margin-right: 18px;">Deskripsi Contact</label>
                                <input name="descContact" class="form-control" type="text" required="required">
                            </div>
                            <div class="form-group" style="margin-bottom: 5px;">
                                <label style="margin-right: 18px;">Email</label>
                                <input name="emailContact" class="form-control" type="text" required="required">
                            </div>
                           <div class="form-group" style="margin-bottom: 5px;">
                                <label style="margin-right: 18px;">Telepon</label>
                                <input name="tlpContact" class="form-control" type="number" required="required" min="0">
                            </div>
                            <div class="form-group" style="margin-bottom: 5px;">
                                <label style="margin-right: 18px;">Fax</label>
                                <input name="faxContact" class="form-control" type="number" required="required" min="0">
                            </div>

                            
                        <div class="form-inline" style="margin-top: 20px;">
                        <a class="btn btn-warning"  onclick="kosongkan()"><i class="fa fa-eraser"></i> Kosongkan</a>
                        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan Contact</button>
                        </div>

                    </div></form>
                    <script>
                    function kosongkan() {
                        document.getElementById("formberita").reset();
                    }
                    </script>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

