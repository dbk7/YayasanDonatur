<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Edit Data Berita
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Edit Data Berita
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                
                <div class="row">
                    <div class="col-lg-12">
                     <form action="<?= site_url('admin/editberita/'.$berita->idBerita);?>" enctype="multipart/form-data" method="post" accept-charset="utf-8" id="formberita">
                            <div class="form-group" style="margin-bottom: 5px;">
                                <label style="margin-right: 18px;">Judul Berita</label><span class="pull-right"><strong>Tanggal Edit: <?=date('d F Y');?></strong></span>
                                <input name="judulBerita" class="form-control" type="text" required="required" value="<?=$berita->judulBerita?>">
                            </div>

                            <div class="form-group" style="margin-bottom: 20px;">
                                <label style="margin-right: 4px;">Gambar Berita</label><br>
                                <img src="<?=base_url('assets/img/berita/'.$berita->fotoBerita)?>" height="200px" alt="No pict" /><br>
                                <label style="margin-right: 4px;">Ubah Gambar Berita</label><span><i>* Abaikan jika tidak ingin mengubah gambar</i></span>
                                <input name="fotoBerita" class="btn btn-default" type="file">
                                <input name="fotoDefault" type="hidden" value="<?=$berita->fotoBerita?>">

                            </div>
                            <?=$this->session->flashdata('error')?>
                        <div class="form-inline">
                            <label>Isi Berita</label>
                            <textarea name="deskripsi" rows="20px;"><?=$berita->deskripsi?></textarea>
                        </div>
                        <div class="form-inline" style="margin-top: 20px;">
                        <a class="btn btn-warning"  onclick="kosongkan()"><i class="fa fa-eraser"></i> Kosongkan</a>
                        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan Berita</button>
                        </div>

                    </div></form>
                    <script>
                    function kosongkan() {
                        document.getElementById("formberita").reset();
                    }
                    </script>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

