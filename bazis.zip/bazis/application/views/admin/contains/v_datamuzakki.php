<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Data Muzakki
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Data Muzakki
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                
                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>ID Muzakki</th>
                                        <th>User Name</th>
                                        <th>Nama Lengkap</th>
                                        <th>Tanggal Lahir</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Email</th>
                                        <th>No. Tlp</th>
                                        <th>Alamat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($muzakki as $mzk): ?>
                                    <tr class="success">
                                        <td><?=$mzk->idMuzakki?></td>
                                        <td><?=$mzk->userName?></td>
                                        <td><?=$mzk->namaLengkap?></td>
                                        <td><?=$mzk->tglLahir?></td>
                                        <td><?=$mzk->jenisKelamin?></td>
                                        <td><?=$mzk->email?></td>
                                        <td><?=$mzk->noTlp?></td>
                                        <td><?=$mzk->alamat?></td>
                                     </tr>
                                 <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->