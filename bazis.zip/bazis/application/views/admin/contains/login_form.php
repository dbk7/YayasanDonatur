   <div class="col-lg-4"></div>
   <div class="col-lg-4">
   <h1 class="text-center">Silahkan Masuk</h1>

         <?php echo validation_errors();  echo form_open('verifylogin');?>
                <div class="form-group has-success">
                         <label class="control-label" for="inputSuccess">Username</label>
                                <input type="text" class="form-control" name="username">
                            </div>

                            <div class="form-group has-warning">
                                <label class="control-label" for="inputWarning">Password</label>
                                <input type="text" class="form-control"  name="password">
                            </div>

                            <div class="form-group has-error">
                                <input type="submit" class="btn btn-success" id="inputError" value="Masuk">
                            </div>

     </div>
     <div class="col-lg-4"></div>