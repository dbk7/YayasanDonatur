<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Data Artikel
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Data Artikel
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                
                <div class="row">
                    <div class="col-lg-12">
                       <a href="<?=base_url('admin/tambahArtikel')?>" class="btn btn-success" style="margin-bottom: 10px;"><i class="fa fa-plus"></i> Tambah Artikel Baru</a>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>ID Artikel</th>
                                        <th>Judul Artikel</th>
                                        <th>Deskripsi</th>
                                        <th>Foto Artikel</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($read as $b): ?>
                                    <tr class="success">
                                        <td><?=$b->idArticle?></td>
                                        <td><?=$b->nameArticle?></td>
                                        <td><?=substr($b->descArticle,0,200)?>...</td>
                                        <td><img src="<?=base_url('assets/img/'.$b->fotoArticle)?>" height="100px" alt="No pict"></td>
                                        <td>
                                        <a href="<?=site_url('admin/hapusArtikel/'.$b->idArticle)?>" class="btn btn-default"><i class="fa fa-trash"></i> Hapus</a>
                                            <a href="<?=site_url('admin/editArtikel/'.$b->idArticle)?>" class="btn btn-default"><i class="fa fa-edit"></i> Edit &nbsp;&nbsp;&nbsp;</a>
                                        </td>
                                     </tr>
                                 <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->