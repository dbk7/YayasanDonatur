<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Laporan Keuangan
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Laporan Keuangan  

                       </ol>
                      
                            
                
                <div class="row">
                    <div class="col-lg-6">
                    <h4 class="text-center list-group-item">Donasi Masuk</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Tanggal Donasi</th>
                                        
                                        <th>Nominal</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($donasi as $don): ?>
                                    <tr class="success">
                                        <td><?=$don->tglDonasi?></td>
                                        <td>Rp. <?=number_format($don->nominal)?></td>
                                        
                                     </tr>
                                 <?php endforeach;?>
                                 <tfoot>
                                 <th><span class="pull-right">Total</span></th>
                                 <th>Rp. <?=number_format($total);?></th>
                                     
                                 </tfoot>
                                </tbody>
                            </table>
                        </div>
                    </div>
              
                    <div class="col-lg-6">
                        <div class="table-responsive">
                        <h4 class="text-center list-group-item">Donasi Keluar</h4>
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Tanggal Penyaluran</th>
                                        
                                        <th>Nominal</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($penyaluran as $don): ?>
                                    <tr class="success">
                                        <td><?=$don->tglPenyaluran?></td>
                                        <td>Rp. <?=number_format($don->nominalPenyaluran)?></td>
                                        
                                     </tr>
                                 <?php endforeach;?>
                                 <tfoot>
                                 <th><span class="pull-right">Total</span></th>
                                 <th>Rp. <?=number_format($totalout);?></th>
                                     
                                 </tfoot>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="col-lg-12">
                    <h4 class="text-center list-group-item">Sisa Dana Donasi per tanggal <?=date('d M Y');?> :&nbsp;&nbsp;<b>Rp. <?=number_format($total - $totalout);?></b></h4>
                   
                 </div>



                </div>
                <!-- /.row -->




            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->