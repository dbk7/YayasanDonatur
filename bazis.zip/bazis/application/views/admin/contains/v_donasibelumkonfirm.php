<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Donasi Belum Konfirmasi
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Donasi Belum Konfirmasi
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                <?=$this->session->flashdata('pesan')?>
                
                <div class="row">
                    <div class="col-lg-12"><?php if($this->data['donasi']): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>ID Donasi</th>
                                        <th>Tanggal Donasi</th>
                                        <th>Jenis Donasi</th>
                                        <th>Nama Muzakki</th>
                                        <th>Rekening Tujuan</th>
                                        <th>Rekening Pemilik</th>
                                        <th width="300px;">Nominal</th>
                                        <th>Bukti Donasi</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($donasi as $don): ?>
                                    <tr class="success">
                                        <td><?=$don->idDonasi?></td>
                                        <td><?=$don->tglDonasi?></td>
                                        <td><?=$don->namaJenisDonasi?></td>
                                        <td><?=$don->namaLengkap?></td>
                                        <td><?=$don->noRekening?></td>
                                        <td><?=$don->noRekPemilik?></td>
                                        <td>Rp. <?=number_format($don->nominal)?></td>
                                        <td><a href="<?=base_url('assets/img/transfer/'.$don->gambar)?>" height="100px" alt="No pict">  <i class="fa fa-eye"></i> Lihat </a></td>
                                        <td><a href="<?=site_url('admin/ubahstatusdonasi/'.$don->idDonasi)?>" class="btn btn-default" onclick = "if (! confirm('Apakah anda yakin donasi sudah diterima?')) { return false; }"><i class="fa fa-check"></i> Donasi Diterima</a></td>
                                     
                                     </tr>
                                 <?php endforeach;?>
                                 <tfoot>
                                 <th colspan="6"><span class="pull-right">Total Donasi Belum di Konfirmasi</span></th>
                                 <th>Rp. <?=number_format($total);?></th>
                                     
                                 </tfoot>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php else: ?>
                    <h3 class="text-center">Donasi telah diterima semua...</h3><br/>
                <?php endif;?>
                   
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->