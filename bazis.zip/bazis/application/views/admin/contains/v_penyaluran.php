<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Penyaluran Dana
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Penyaluran Dana
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                
                <div class="row">
                    <div class="col-lg-8">
                   
                    <form action="<?= site_url('admin/penyaluran');?>" method="post" id="formberita">
                            <div class="form-group" style="margin-bottom: 5px;">
                                <label style="margin-right: 18px;">Tujuan Penyaluran</label>
                                <input name="tujuan" class="form-control" type="text" required="required">
                            </div>
                            <div class="form-group" style="margin-bottom: 5px;">
                                <label style="margin-right: 18px;">Nominal</label>
                                <input name="nominalPenyaluran" class="form-control" type="number" max="<?=$total-$totalout?>" min="1" required="required">
                            </div>
                            <div class="form-group" style="margin-bottom: 5px;">
                                <label style="margin-right: 18px;">Keterangan</label>
                                <textarea class="form-control" name="keterangan" ></textarea>
                            </div>
                                                     
                        <div class="form-inline" style="margin-top: 20px;">
                       
                        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                        </div>
                        
                       
                    </div></form>
                    </div>
                    <hr/>
                   <div class="row">
                    <div class="col-lg-12">
                    <h4>Data Penyaluran Dana</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>ID Penyaluran</th>
                                        <th>Tanggal Penyaluran</th>
                                        <th>Nominal Penyaluran</th>
                                        <th>Tujuan Penyaluran</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($penyaluran as $p): ?>
                                    <tr class="success">
                                        <td><?=$p->idPenyaluran?></td>
                                        <td><?=$p->tglPenyaluran?></td>
                                        <td>Rp. <?=number_format($p->nominalPenyaluran)?></td>
                                        <td><?=$p->tujuan?></td>
                                        <td><?=$p->keterangan?></td>
                                      
                                     </tr>
                                 <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->