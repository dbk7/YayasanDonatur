<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Data Berita
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Data Berita
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                
                <div class="row">
                    <div class="col-lg-12">
                       <a href="<?=base_url('admin/tambahberita')?>" class="btn btn-success" style="margin-bottom: 10px;"><i class="fa fa-plus"></i> Tambah Berita Baru</a>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>ID Berita</th>
                                        <th>Judul Berita</th>
                                        <th>Deskripsi</th>
                                        <th>Waktu Posting</th>
                                        <th>Foto Berita</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($read as $b): ?>
                                    <tr class="success">
                                        <td><?=$b->idBerita?></td>
                                        <td><?=$b->judulBerita?></td>
                                        <td><?=substr($b->deskripsi,0,200)?>...</td>
                                        <td><?=$b->waktuPost?></td>
                                        <td><img src="<?=base_url('assets/img/berita/'.$b->fotoBerita)?>" height="100px" alt="No pict"></td>
                                        <td><a href="<?=site_url('berita/read/'.$b->idBerita)?>" class="btn btn-default"><i class="fa fa-eye"></i> Lihat &nbsp;</a>
                                        <a href="<?=site_url('admin/hapusberita/'.$b->idBerita)?>" class="btn btn-default"><i class="fa fa-trash"></i> Hapus</a>
                                            <a href="<?=site_url('admin/editberita/'.$b->idBerita)?>" class="btn btn-default"><i class="fa fa-edit"></i> Edit &nbsp;&nbsp;&nbsp;</a>
                                        </td>
                                     </tr>
                                 <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->