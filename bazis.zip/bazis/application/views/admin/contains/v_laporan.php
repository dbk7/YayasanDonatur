<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Laporan Keuangan
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Laporan Keuangan  

                       </ol>
                        
                       <div class="col-lg-12">
                       <div class="col-lg-2">
                        <ol class="breadcrumb">
                       <li class="active"> Bulan : </div>
                       <div class="col-lg-2">
                       <form action="admin/laporan2" method="get">
                       <select class="form-control" name="bulan" required="required">
                                <option value="1">Januari</option>
                                 <option value="2">februari</option>
                                 <option value="3">maret</option>
                                 <option value="4">april</option>
                                 <option value="5">mei</option>
                                 <option value="6">juni</option>
                                 <option value="7">juli</option>
                                 <option value="8">agustus</option>
                                 <option value="9">september</option>
                                 <option value="10">oktober</option>
                                 <option value="11">november</option>
                                 <option value="12">desember</option>
                                
                            </select>
                            </form>
                            </div>
                              <div class="col-lg-2">
                       <select class="form-control" name="tahun" div id="select" required="required">
                                <option value="2018">2018</option>
                                 <option value="2019">2019</option>
                                 <option value="2020">2020</option>
                                 <option value="2021">2021</option>
                                 <option value="2022">2022</option>
                                 <option value="2023">2023</option>
                                 <option value="2024">2024</option>
                                 <option value="2025">2025</option>
                                 <option value="2026">2026</option>
                                 <option value="2027">2027</option>
                                 <option value="2028">2028</option>
                                 <option value="2029">2029</option>
                                 <option value="2030">2030</option>
                                
                            </select>
                            </div>
                             <a href="<?=base_url('admin/laporan2')?>" class="btn btn-success" style="margin-bottom: 10px;"><i class="fa fa-search"></i>Lihat</a>
                             </ol>
                    </div>
                </div>
               
               




            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->