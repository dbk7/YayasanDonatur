<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Data Status Donasi
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Data Status Donasi
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                
                <div class="row">
                    <div class="col-lg-12">
                       <a href="<?=base_url('admin/tambahstatusdonasi')?>" class="btn btn-success" style="margin-bottom: 10px;"><i class="fa fa-plus"></i> Tambah Status Donasi</a>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>ID Donasi</th>
                                        <th width="800px;">Ket Donasi</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($statusdonasi as $std): ?>
                                    <tr class="success">
                                        <td><?=$std->idStatusDonasi?></td>
                                        <td><?=$std->ketDonasi?></td>
                                        <td><a href="<?=site_url('admin/hapusstatusdonasi/'.$std->idStatusDonasi)?>" class="btn btn-default"><i class="fa fa-trash"></i> Hapus</a>
                                            <a href="<?=site_url('admin/editstatusdonasi/'.$std->idStatusDonasi)?>" class="btn btn-default"><i class="fa fa-edit"></i> Edit &nbsp;&nbsp;&nbsp;</a>
                                        </td>
                                     </tr>
                                 <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->