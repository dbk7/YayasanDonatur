<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Donasi Diterima
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Donasi Diterima
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <?=$this->session->flashdata('pesan')?>
                
                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>ID Donasi</th>
                                        <th>Jenis Donasi</th>
                                        <th>Tanggal Donasi</th>
                                        <th>Nama Muzakki</th>
                                        <th>Rekening Tujuan</th>
                                        <th>Rekening Pemilik</th>
                                        <th width="300px;">Nominal</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($donasi as $don): ?>
                                    <tr class="success">
                                        <td><?=$don->idDonasi?></td>
                                         <td><?=$don->namaJenisDonasi?></td>
                                        <td><?=$don->tglDonasi?></td>
                                       
                                        <td><?=$don->namaLengkap?></td>
                                        <td><?=$don->noRekening?></td>
                                         <td><?=$don->noRekPemilik?></td>
                                        <td>Rp. <?=number_format($don->nominal)?></td>
                                        
                                     </tr>
                                 <?php endforeach;?>
                                 <tfoot>
                                 <th colspan="6"><span class="pull-right">Total Donasi Diterima</span></th>
                                 <th>Rp. <?=number_format($total);?></th>
                                     
                                 </tfoot>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->