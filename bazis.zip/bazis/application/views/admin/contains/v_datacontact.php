<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Data Contact
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="<?=base_url('admin')?>">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Data Contact
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

                
                <div class="row">
                    <div class="col-lg-12">
                       <a href="<?=base_url('admin/tambahcontact')?>" class="btn btn-success" style="margin-bottom: 10px;"><i class="fa fa-plus"></i> Tambah Contact Baru</a>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>ID Contact</th>
                                        <th>Deskripsi </th>
                                        <th>Email </th>
                                        <th>Telepon</th>
                                        <th>Fax</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php foreach ($contact as $con): ?>
                                    <tr class="success">
                                        <td><?=$con->idContact?></td>
                                        <td><?=$con->descContact?></td>
                                        <td><?=$con->emailContact?></td>
                                        <td><?=$con->tlpContact?></td>
                                        <td><?=$con->faxContact?></td>
                                        <td><a href="<?=site_url('admin/hapuscontact/'.$con->idContact)?>" class="btn btn-default"><i class="fa fa-trash"></i> Hapus</a>
                                            <a href="<?=site_url('admin/editcontact/'.$con->idContact)?>" class="btn btn-default"><i class="fa fa-edit"></i> Edit &nbsp;&nbsp;&nbsp;</a>
                                        </td>
                                     </tr>
                                 <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->