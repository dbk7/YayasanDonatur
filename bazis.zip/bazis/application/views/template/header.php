	<body>
  	<div class="header container">
      <div class="visible-xs visible-sm col-xs-12 col-sm-12 text-center sm-logo">
        <a rel="home" href="index.html">
          <img src="<?=base_url()?>assets/logo/bazis.png" width="100" alt="logo">
        </a>
      </div>
  	</div>
		<div class="navbar" role="navigation">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
			</div>
            
			<div class="collapse navbar-collapse">
				<ul class="nav navbar-nav">
				 <li class= "hidden-xs hidden-sm">
            <a rel="home" href="<?=site_url();?>"><img class="logo" src="<?=base_url()?>assets/logo/bazis.png" width="100" alt="logo"></a>
            
          	</li>
          	<li class="<?php if ($this->uri->segment(1)=='berita'){ echo 'selected'; }else{ echo 'unselected';} ?>"><a href="<?=base_url('berita');?>">BERITA</a></li>
					<li class="<?php if ($this->uri->segment(1)=='kegiatan'){ echo 'selected'; }else{ echo 'unselected';} ?>"><a href="<?=base_url('kegiatan');?>">KEGIATAN</a></li>
					<li class="<?php if ($this->uri->segment(1)=='rekening'){ echo 'selected'; }else{ echo 'unselected';} ?>"><a href="<?=base_url('rekening');?>">REKENING</a></li>
					<li><a href="#"  class="dropdown-toggle" data-toggle="dropdown">DONASi<b class="caret"></b></a>
               		<ul class="dropdown-menu list-inline">
               		<li class="dropdown"><a href="<?=base_url('donasi/jenisdonasi/1/zakat');?>">Shadaqah</a></li>
               		<li class="dropdown"><a href="<?=base_url('donasi/jenisdonasi/2/infaq');?>">Infaq</a></li>
			   		</ul>
               		</li>
					<li class="<?php if ($this->uri->segment(1)=='contact'){ echo 'selected'; }else{ echo 'unselected';} ?>"><a href="<?=base_url('contact');?>">KONTAK KAMI</a></li>
					<?php if($this->session->userdata('login')==FALSE){ ?>
                    <li class="unselected"><a href="<?=base_url('muzakki');?>">DONATUR</a></li>
             		<?php }else{ ?>
              <li><a href="#"  class="dropdown-toggle" data-toggle="dropdown">&nbsp;<?php echo ($this->session->userdata('userName')); ?> &nbsp;<b class="caret"></b></a>
               <ul class="dropdown-menu list-inline">
               <li class="dropdown"><a href="<?=base_url('donasi/histori');?>">History Donasi</a></li>
               <li class="dropdown"><a href="<?=base_url('muzakki/logout');?>">Logout</a></li>
			   </ul>
               </li>
			   <?php } ?>
				</ul>
			</div>
		