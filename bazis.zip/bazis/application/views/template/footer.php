</div>
 <!-- ============FOOTER============= -->
      <footer id="footer"> 
        <div class="footer-content text-center">
             <span>Copyright <?=date("Y");?></span>
             <span> <a href="<?=base_url()?>">Pondok Yatim H.Caong</a></span><br>&nbsp;
        </div>

    </footer>

	<!-- script references -->
		<script src="<?=base_url()?>assets/js/jquery.min.js"></script>
		<script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>assets/js/nav-hover.min.js"></script>
    <script type="text/javascript"  src="<?=base_url()?>assets/js/jquery.bxslider.min.js"></script>
    <script type="text/javascript"  src="<?=base_url()?>assets/js/main.js"></script>
    <!-- Place in the <head>, after the three links -->
    <script>
     $('.testimonials-slider').bxSlider({
      slideWidth: 800,
      minSlides: 1,
      maxSlides: 1,
      slideMargin: 32,
      auto: true,
      autoControls: true
      });
    </script>
		<script type="text/javascript">
		</script>
	</body>
</html>
