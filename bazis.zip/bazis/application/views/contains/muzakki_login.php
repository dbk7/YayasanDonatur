
     <div class="divider col-sm-12 col-xs-12 col-md-12">
           <div class="header-text text-center"><span>Muzakki</span> Login</div>
        </div>
            <div class="contact-form-full col-md-5 col-sm-5 col-xs-11">

              <div class="inner contact">
                <!-- Form Area -->
                <div class="contact-form">
                    <!-- Form -->
                  <?php
 					echo form_open('muzakki/login_proses');
				  ?>
                        <div class="col-xs-12 wow animated slideInLeft" data-wow-delay=".5s">
                            <!-- Name -->
                            <input type="text" name="userName"  required="required" class="form" placeholder="User Name" />
                            <!-- Email -->
                            <input type="password" name="password"  required="required" class="form" placeholder="Password" />

                        </div><!-- End Left Inputs -->
                        <!-- Right Inputs -->
                        <!-- Bottom Submit -->
                        <div class="relative fullwidth col-xs-12">
                            <!-- Send Button -->
                            <button type="submit" class="form-btn semibold">Login</button><br></br>
                        </div><!-- End Bottom Submit -->
                        <!-- Clear -->
                    </form>
				 <p>Belum Punya Akun Klik<a href="<?php echo site_url('muzakki/register'); ?>">&nbsp;Register</a></p>
                </div><!-- End Contact Form Area -->
            </div><!-- End Inner -->
          </div>
            <!-- wrapper -->
        </section>
      
  