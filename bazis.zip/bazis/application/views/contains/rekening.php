     <div class="divider col-sm-12 col-xs-12 col-md-12">
           <div class="header-text text-center"><span>Rekening Zakat</span></div>
        </div>
        
            <div class="contact-form-full col-md-5 col-sm-5 col-xs-11">

              <div class="inner contact">
                <!-- Form Area -->
                <div class="contact-form">
                    <!-- Form -->
                    <?php foreach ($rekening as $rz): ?>
                        <!-- Left Inputs -->
                        <div class="col-md-12">
                            <label class="col-md-4"><?=$rz->namaBank?></label><label class="col-md-8">: <?=$rz->noRekening?>&nbsp;(<?=$rz->namaJenisDonasi?>) </label>
                        </div><?php endforeach; ?>

                </div>
            </div>
          </div>
               
  