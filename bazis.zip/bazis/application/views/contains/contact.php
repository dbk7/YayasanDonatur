            <div class="divider col-sm-12 col-xs-12 col-md-12">
           <div class="header-text text-center"><span>Contact</span> Us</div>
        </div>
					 <?php foreach ($contact as $ct): ?>
                   <div class="contact-form-full col-md-5 col-sm-5 col-xs-11">

              <div class="inner contact">
                <!-- Form Area -->
                <div class="contact-form">
                        <div class="col-md-12">
                            <label class="col-md-12"> <?=$ct->descContact?></label>
                            <label class="col-md-4">Email</label><label class="col-md-8">: <?=$ct->emailContact?></label>
                           	<label class="col-md-4">No Telepon </label><label class="col-md-8">: <?=$ct->tlpContact?></label>
                            <label class="col-md-4">No Fax</label><label class="col-md-8">: <?=$ct->faxContact?></label>
                        </div>
                        <?php endforeach; ?>
                        </div>
                        </div>
                    </div>
        
           
                