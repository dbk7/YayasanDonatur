<?php
class pdf {
 
    function __construct() {
        include_once APPPATH . '/views/contains/fpdf/fpdf.php';
    }
}
?>