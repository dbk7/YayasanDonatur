<div class="divider col-sm-12 col-xs-12 col-md-12">
<div class="header-text text-center"><span>Register</span> Sukses</div>
 <h2 class="text-center">Selamat Anda Berhasil Registrasi</h2>
 <h3 class="text-center">Silahkan Login Untuk Malanjutkan Donasi Anda...<a href="<?php echo site_url('muzakki'); ?>" class="buttona">Login</a></h3>
 <br></br>