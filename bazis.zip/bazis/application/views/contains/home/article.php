     <div class="divider col-sm-12 col-xs-12 col-md-12">
              <div class="header-text text-center"><br><span>Artikel</span></div>
    </div>     
 <section>
          <div class="col-md-12 testimonial-blog">
             <div id="wrapper">
                <div class="testimonials-slider">
                <?php foreach($article as $ar):?>
                  <div class="slide">
                    <div class="testimonials-carousel-thumbnail"><img width="120" alt="" src="<?=base_url('assets/img/'.$ar->fotoArticle)?>"></div>
                      <div class="testimonials-carousel-context">
                      <div class="testimonials-name"><?=$ar->nameArticle?></span>
                        </div>
                        <div class="testimonials-carousel-content">
                        <p><?=$ar->descArticle?></p>
                        </div>
                      </div>
                    </div><?php endforeach ?>
              </section>