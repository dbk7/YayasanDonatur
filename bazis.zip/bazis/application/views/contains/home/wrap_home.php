<?php
require_once('slider.php');
require_once('headline.php');
require_once('article.php');

