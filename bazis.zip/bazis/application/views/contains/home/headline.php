    <div class="divider col-sm-12 col-xs-12 col-md-12">
      <div class="header-text text-center"><span>Kegiatan Terkini</span></div>
    </div>
    <?php foreach ($kegiatan as $row): ?>
  <section class="blog">
				<div class="item col-md-4">
           <div class="blok-read-sm">
             <a href="single1.html" class="hover-image">
                <img src="<?=base_url('assets/img/kegiatan/'.$row->fotoKegiatan)?>" class="img-responsive"  alt="image"/>
                <span class="layer-block"></span>
             </a>
            <div class="content-block">
              <span class="point-caption bg-blue-point"></span>
              <span class="bottom-line bg-blue-point"></span>
                <h4><?=$row->judulKegiatan?></h4>
                <p><?=substr($row->deskripsi,0,200)?></p>
                <div class="button-main bg-fio-point pull-right"><a href="<?=site_url('kegiatan/read/'.$row->idKegiatan)?>">read more</a></div>
            	</div>
                <div class="panel-footer">
                                    <div class="pull-left">
                                        <small>Post Date: <?=$row->waktuPost?> </small>
                                    </div>
                                    <div class="clearfix"></div>
                                  </div>
            </div>
          </div>
     <?php endforeach; ?>


			
