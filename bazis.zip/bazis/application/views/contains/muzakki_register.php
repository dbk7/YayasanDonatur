     <div class="divider col-sm-12 col-xs-12 col-md-12">
           <div class="header-text text-center"><span>Muzakki</span> Register</div>
        </div>
            <div class="contact-form-full col-md-5 col-sm-5 col-xs-11">

              <div class="inner contact">
                <!-- Form Area -->
                <div class="contact-form">
                    <!-- Form -->
                    <form method="post" 
					action="<?=site_url('muzakki/register_proses')?>">
                        <!-- Left Inputs -->
                        <div class="col-xs-12 wow animated slideInLeft" data-wow-delay=".5s">
                            <input type="text" name="username" required="required" class="form" placeholder="User Name" />
                            <input type="text" name="namalengkap"  required="required" class="form" placeholder="Nama Lengkap" />
                            <input type="password" name="password"  required="required" class="form" placeholder="Password" />
                            <input type="date" name="tgllahir"  class="form" placeholder="Tanggal Lahir" />
                            <input type="radio" name="jeniskelamin" value="laki-laki" required><span>Laki-Laki</span><br/>
                            <input type="radio" name="jeniskelamin" value="perempuan" required><span>Perempuan</span><br/>
                            <input type="email" name="email" required="required" class="form" placeholder="Email" />
                            <input type="number" name="notlp" required="required" class="form" placeholder="No Telepon" />
                            <input type="text" name="alamat" required="required" class="form" placeholder="Alamat" />

                        </div><!-- End Left Inputs -->
                        <!-- Right Inputs -->
                        <!-- Bottom Submit -->
                        <div class="relative fullwidth col-xs-12">
                            <!-- Send Button -->
                            <button type="submit" name="submit" class="form-btn semibold">Register</button><br></br>
                        </div><!-- End Bottom Submit -->
                        <!-- Clear -->
                        <div class="clear"></div>
                        
                    </form>

                </div><!-- End Contact Form Area -->
            </div><!-- End Inner -->
          </div>
            <!-- wrapper -->
        </section>
      
  