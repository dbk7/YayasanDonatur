<div class="divider col-sm-12 col-xs-12 col-md-12">
<div class="blok-read-sm">
<h3 class="text-center"><?=$berita->judulBerita?></h3>
	 <div class="blog-event">
              <div class="featured-img">
                  <img src="<?=base_url('assets/img/berita/'.$berita->fotoBerita)?>"  width="600" alt=""  style="margin-left:20px">
              </div>
              <div class="featured-blog">
                  <p style="text-align:justify; margin-right:20px; margin-left:20px"><?=$berita->deskripsi?></p>
              </div>
            </div>
  </div>
 </div>