        <div class="divider col-sm-12 col-xs-12 col-md-12">
            <div class="header-text text-center"><span>Berita</span></div>
        </div>

        <section id="blog-isotope" class="subpage bg-white">
        <div class="overlay-light">
            <div id="content" class="container">
                <!-- posts -->  
                <div class="posts">
                <?php foreach ($berita as $row): ?>
                    <!-- post 1 -->
                    <div class="post item col-md-4 col-xs-12 col-sm-4">
                           <div class="panel">
                                  <div class="panel-header">
                                     <img src="<?=base_url('assets/img/berita/'.$row->fotoBerita)?>" class="img-responsive"  alt="image"/>
                                  </div>
                                  <div class="panel-body">
                                       <h3 class="post-title"><a href=""><?=$row->judulBerita?></a></h3>

                                        <p><?=substr($row->deskripsi,0,200)?>.....</p>
                                        <div class="pull-right"><a class="btn btn-default" href="<?=site_url('berita/read/'.$row->idBerita)?>"><span class="read-more">Read More</span></a></div>
                                  </div>
                                  <div class="panel-footer">
                                    <div class="pull-right">
                                        <small>Post Date: <?=$row->waktuPost?> </small>
                                    </div>
                                    <div class="clearfix"></div>
                                  </div>
                            </div>
                    </div>
                  <?php endforeach; ?>
                    


                <!-- pager -->
                  <ul class="col-md-12 pager wow animated fadeIn">
                    <li class="previous"><a href="#">&larr; Older</a></li>
                    <li class="next"><a href="#">Newer &rarr;</a></li>
                  </ul><!-- /end pager -->
            </div>
         </div><!-- /end overlay -->
      </section><!--=== / END blog ===-->

   