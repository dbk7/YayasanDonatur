<div class="divider col-sm-12 col-xs-12 col-md-12">

<h3 class="text-center"><?=$kegiatan->judulKegiatan?></h3>
	 <div class="blog-event">
              <div class="featured-img">
                  <img src="<?=base_url('assets/img/kegiatan/'.$kegiatan->fotoKegiatan)?>"width="400" alt="" style="margin-left:20px;" >
              </div>
              <div class="featured-blog">
                  <p style="text-align:justify; margin-right:20px; margin-left:20px"><?=$kegiatan->deskripsi?></p>
              </div>
     
  </div>
 </div>