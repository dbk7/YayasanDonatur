    <div class="divider col-sm-12 col-xs-12 col-md-12">
           <div class="header-text text-center"><span>History Donasi</span></div>
           <table class="table table-hover" align="center" width="100%">
    <tr align="center">
        <td>Jenis Donasi</td>
        <td>Tanggal Donasi</td>
				<td>Nominal Donasi</td>
				<td>Status Donasi</td>
        <td>&nbsp;</td>
	</tr><?php foreach($hasildonasi as $hd): ?>
			<tr align="center">
        <td><?=$hd->namaJenisDonasi?></td>
            	<td><?=$hd->tglDonasi?></td>
                <td>Rp.<?= number_format($hd->nominal)?></td>
                <td><?=$hd->ketDonasi?> </td>
                <td>
               
                <a href="<?=site_url('donasi/konfirmasi/'.$hd->idDonasi)?>" class="btn btn-success">Konfirmasi Transfer</a>
                
                </td>
			</tr><?php endforeach; ?>

		</table>
        </div>
 