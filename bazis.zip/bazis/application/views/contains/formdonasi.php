     <div class="divider col-sm-12 col-xs-12 col-md-12">
           <div class="header-text text-center"><span>Formulir Donasi</span></div>
        </div>
        
            <div class="contact-form-full col-md-5 col-sm-5 col-xs-11">

              <div class="inner contact">
                <!-- Form Area -->
                <div class="contact-form">
                    <!-- Form -->
                    <form method="post" 
					action="<?=site_url('donasi/donasi_proses')?>">
                        <!-- Left Inputs -->
                        <div class="col-md-12">
                            <label class="col-md-4">Nama Donatur</label><label class="col-md-8">: <?=$muzakki->namaLengkap?></label>
                            <label class="col-md-4">Alamat Donatur</label><label class="col-md-8">: <?=$muzakki->alamat?></label>
                           	<label class="col-md-4">Email Donatur</label><label class="col-md-8">: <?=$muzakki->email?></label>
                            <label class="col-md-4">No. Telepon</label><label class="col-md-8">: <?=$muzakki->noTlp?>
                        </div>

                        </div><!-- End Left Inputs -->
                        <!-- Right Inputs -->
                        <!-- Bottom Submit -->
                        <div class="  col-xs-12">
                            <!-- Send Button --><br>
                            <select class="form-control" name="rek" div id="select" required="required">
                                <option>Pilih No. Rekening</option>
                                <?php foreach ($rek as $r): ?>
                                <option value="<?=$r->noRekening?>"><?= $r->noRekening.' ('.$r->namaBank .')'?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="hidden" name="jenisdonasi" value="<?=$r->idJenisDonasi?>">
                            <input type="number" min="100000" name="jmldonasi" required="required" class="form" placeholder="Jumlah Donasi" />
                            <input type="hidden" name="idMuzakki" value="<?=$muzakki->idMuzakki?>">
                            <button type="submit" name="submit" class="form-btn">Donasikan Sekarang</button>
                        </div><!-- End Bottom Submit -->
                        <!-- Clear -->
                        <div class="clear"></div>
                        
                    </form>

                </div><!-- End Contact Form Area -->
            </div><!-- End Inner -->
          </div>
            <!-- wrapper -->
        </section>
        <div class="spacefill"></div>
      
  