     <div class="divider col-sm-12 col-xs-12 col-md-12">
           <div class="header-text text-center"><span>Konfirmasi Donasi</span></div>
        </div>
        
            <div class="contact-form-full col-md-5 col-sm-5 col-xs-11">

              <div class="inner contact">
                <!-- Form Area -->
                <div class="contact-form">
                    <!-- Form -->
                    <form method="post" action="<?=site_url('donasi/konfirmasi')?>" enctype="multipart/form-data">
                        <!-- Left Inputs -->
                        <div class="col-md-12">
                            <label class="col-md-4">Nama Donatur</label><label class="col-md-8">: <?=$konfirmasidonasi->namaLengkap?></label>
                            <label class="col-md-4">Ket Donasi</label><label class="col-md-8">: <?=$konfirmasidonasi->namaJenisDonasi?></label>
                           	<label class="col-md-4">Nominal</label><label class="col-md-8">: Rp.<?= number_format($konfirmasidonasi->nominal)?></label>
                        </div>
                        

                        </div><!-- End Left Inputs -->
                        <!-- Right Inputs -->
                        <!-- Bottom Submit -->
                        <div class="  col-xs-12">
                            <!-- Send Button --><br>
                            <input type="text"  name="nama" required="required" class="form" placeholder="Nama Pemilik Rekening" />
                            <input type="number"  name="no" required="required" class="form" placeholder="Nomer Rekening" />
                            <input type="file"  name="gambar" required="required" class="form" placeholder="Pilih File" />
                            <input type="hidden" name="idMuzakki" value="<?=$muzakki->idMuzakki?>">
                            <input type="hidden" name="idDonasi" value="<?=$konfirmasidonasi->idDonasi?>">
                            <button type="submit" name="submit" class="form-btn">Konfirmasi Sekarang</button>
                            <span><?=$this->session->flashdata('error')?></span>
                        </div><!-- End Bottom Submit -->
                        <!-- Clear -->
                        <div class="clear"></div>
                        
                    </form>

                </div><!-- End Contact Form Area -->
            </div><!-- End Inner -->
          </div>
            <!-- wrapper -->
        </section>
        <div class="spacefill"></div>
      
  